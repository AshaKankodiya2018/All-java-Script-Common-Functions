﻿
if (typeof (CrmJS) === "undefined") {
    CrmJS = { __namespace: true };
}

CrmJS.OpportunityFunctions = {

    //********************************************************
    //****** On Reservation Load **********
    //********************************************************
    onLoad: function (executionContext) {
        CrmJS.OpportunityFunctions.initialize(executionContext);
        CrmJS.OpportunityFunctions.process(executionContext);
    },

    initialize: function (executionContext) {
        Common.globalUIContext = executionContext;
    },

    process: function (executionContext) {
    },

    //*********** ON MarketPlan Change *********************
    marketPlanOnChange: function (executionContext) {
        CrmJS.CommonFunctions.cancelMarketPlan(executionContext, "bna_marketplan");
        CrmJS.CommonFunctions.setCurrentDate(executionContext, "bna_marketplan", "bna_startdateoftheplan");
    },

    namespace: true
};