﻿
if (typeof (CrmJS) === "undefined") {
    CrmJS = { __namespace: true };
}

CrmJS.CommonFunctions = {

    //**************** Common functions **************

    //This below function is used for Lead and Opportunity when anyone change market plan on lead and opportunity it will delete all incomplete/open activities.
    cancelMarketPlan: function (executionContext, attributeName) {
        var formContext = Common.getFormContext(executionContext);
        if (formContext != null) {
            var formType = formContext.ui.getFormType();
            if (formType === Common.updateFormType) {
                var recordID = Common.removeCurlyBraceFromGuid(formContext.data.entity.getId());
                var entityName = formContext.data.entity.getEntityName();
                var marketPlan = Common.getAttributeValue(executionContext, attributeName);
                if (Common.isBlankOrNull(marketPlan)) {
                    Common.openConfirmDialog("Confirm", "Cancel", "", "Are you sure you want to change the market plan? This action will clear (delete) all incomplete/open activities associated with this Market Plan", "Confirmation Dialog", 200, 450,
                        function (success) {
                            if (success.confirmed) {
                                var params = {
                                    "Guid": recordID
                                }

                                var url = "https://prod-92.westus.logic.azure.com:443/workflows/7f2b111cfc9c425cbebf420e4b4ab41b/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=vDtyA7T1TKWR5Xqp1zdb9Sgg-TGAlgFS8Iexuz7AEHU"; // Replace with the actual URL
                                var xhr = new XMLHttpRequest();
                                xhr.open("POST", url, true);
                                xhr.setRequestHeader("Content-Type", "application/json");
                                xhr.send(JSON.stringify(params));
                            }
                            else {
                                var entityRecord = Common.retrieveSingleRecordSync(entityName, recordID, ["_bna_marketplan_value"], null);
                                if (!Common.isBlankOrNull(entityRecord)) {
                                    var marketPlanId = entityRecord["_bna_marketplan_value"];
                                    var marketPlanName = entityRecord["_bna_marketplan_value@OData.Community.Display.V1.FormattedValue"];
                                    var marketPlanEntityName = entityRecord["_bna_marketplan_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                    if (!Common.isBlankOrNull(marketPlanId) &&
                                        !Common.isBlankOrNull(marketPlanName) &&
                                        !Common.isBlankOrNull(marketPlanEntityName)) {
                                        Common.setLookupAttributeValue(executionContext, attributeName, marketPlanId, marketPlanName, marketPlanEntityName);
                                    }
                                }
                            }
                        });
                }
            }
        }
    },

    //This below metod is used for set current date in the field
    setCurrentDate: function (executionContext, getAttributeName, setAttributeName) {
        var attribute = Common.getAttributeValue(executionContext, getAttributeName);
        if (!Common.isBlankOrNull(attribute)) {
            var currentDate = new Date();
            Common.setAttributeValue(executionContext, setAttributeName, currentDate);
        }
    },

    namespace: true
};