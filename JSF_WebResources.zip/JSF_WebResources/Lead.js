﻿
if (typeof (CrmJS) === "undefined") {
    CrmJS = { __namespace: true };
}

CrmJS.LeadFunctions = {

    //********************************************************
    //****** On Reservation Load **********
    //********************************************************
    onLoad: function (executionContext) {
        CrmJS.LeadFunctions.initialize(executionContext);
        CrmJS.LeadFunctions.process(executionContext);
    },

    initialize: function (executionContext) {
        Common.globalUIContext = executionContext;
    },

    process: function (executionContext) {
    },

    //*********** ON MarketPlan Change *********************
    marketPlanOnChange: function (executionContext) {
        CrmJS.CommonFunctions.cancelMarketPlan(executionContext, "bna_marketplan");
        CrmJS.CommonFunctions.setCurrentDate(executionContext, "bna_marketplan", "bna_startdateoftheplan");
    },

    namespace: true
};